﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PadreAnimController : MonoBehaviour
{
    float timer = 0;
    public float timeToDrink = 5;
    Animator anim;

    // Start is called before the first frame update
    void Awake()
    {
        anim = GetComponent<Animator>();
    }

    // Update is called once per frame
    void Update()
    {
        timer += Time.deltaTime;
        if (timer>=timeToDrink)
        {
            if (Random.Range(0,2)==1)
            {
                anim.SetBool("Drink", true);
            }
            timer = 0;
        }
    }
    public void ExitDrinkAnim()
    {
        anim.SetBool("Drink", false);
    }
}
