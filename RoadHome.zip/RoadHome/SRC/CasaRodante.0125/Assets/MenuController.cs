﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;


public class MenuController : MonoBehaviour
{
    public List<Sprite> images;
    float timer = 0;
    public float timeToChange = 2f;
    public bool startIntro = false;
    public Image back;
    int index = 0;
    public GameObject text;

    private void Start()
    {
        FadeManager.Instance.Fade(false, 1, "Juego");
    }
    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Space) && !startIntro)
        {
            startIntro = true;

            back.sprite = images[index];

            index++;
            text.SetActive(false);
        }
        if (startIntro)
        {
            timer += Time.deltaTime;
            if (timer>=timeToChange && index<=2)
            {
                back.sprite = images[index];
                timer = 0;

                index++;
            }
            if (index==3)
            {
                Invoke("Fade",timeToChange);  
                index++;
            }
        }
    }
    public void Fade()
    {
        FadeManager.Instance.Fade(true, 1, "Juego");
    }
}
