﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ManejadorClick : MonoBehaviour {

	bool mobileVersion = true;
	public float velSpeed=2;
	float YaxisRotation;
	float XaxisRotation;
    Arrastrable arrastrable;
    private bool isDragging = false;
    bool hittedDraggable = false;

	private void Awake() {
		if (Application.platform == RuntimePlatform.WindowsPlayer) {
			mobileVersion = false;
		}
	}


	// Update is called once per frame
	void Update () {
		if( Input.GetMouseButton(0))
		{
            if (Input.GetMouseButtonDown(0))
            {
			    Vector3 mousePos = Camera.main.ScreenToWorldPoint(Input.mousePosition);
			    Vector2 mousePos2D = new Vector2(mousePos.x, mousePos.y);
			    RaycastHit2D hit = Physics2D.Raycast(mousePos2D, Vector2.zero);
                if (hit.collider != null )
                {
                    if (hit.collider.GetComponent<Arrastrable>()) { 
                        arrastrable = hit.collider.GetComponent<Arrastrable>();
                        hittedDraggable = true;
                    }
                    else if (hit.collider.GetComponentInParent<Arrastrable>())
                    {
                        arrastrable = hit.collider.GetComponentInParent<Arrastrable>();
                        hittedDraggable = true;
                    }
                }
            }
            if (hittedDraggable)
            { 
                if (Input.GetAxis("Mouse Y") != 0 || Input.GetAxis("Mouse X") != 0)
                {
				    YaxisRotation = Input.GetAxis("Mouse Y") * velSpeed;
				    XaxisRotation = Input.GetAxis("Mouse X") * velSpeed;
                }
                
				if (!isDragging && (!mobileVersion || Application.isEditor))
				{
					arrastrable.Dragging();
                    isDragging = true;
				}

				/*if (Input.touchCount == 1)
				{
					Touch touch = Input.GetTouch(0);

					// Move the cube if the screen has the finger moving.
					if (touch.phase == TouchPhase.Moved)
					{
						float YaxisRotation = Input.GetAxis("Mouse Y") * velSpeed;
						float XaxisRotation = Input.GetAxis("Mouse X") * velSpeed;
						if (parent)
						{
							transform.Rotate(YaxisRotation, -XaxisRotation, 0, Space.World);
						}
						else
						{
							transform.Rotate(-YaxisRotation, 0, 0, Space.Self);
						}
					}

				}*/
			}
		}

        if (Input.GetMouseButtonUp(0))
        {
            Vector3 dir = new Vector3(XaxisRotation, YaxisRotation, 0);
            if (arrastrable != null)
            {
                arrastrable.Drop(dir);
            }
            isDragging = false;
            hittedDraggable = false;
        }

    }
}
