﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class VanFader : MonoBehaviour
{
    public float time;
    public SpriteRenderer ruedas;
    private List<SpriteRenderer> spriteRenderer = new List<SpriteRenderer>();
    private bool move=false;
    bool changingScene = false;
    private void Awake()
    {
        foreach (Transform child in transform)
        {
            spriteRenderer.Add(child.GetComponent<SpriteRenderer>());
        }
        spriteRenderer.Add(ruedas);
    }
    private void FixedUpdate()
    {
        if (move)
        {
             transform.parent.Translate(new Vector3(4, 0, 0) * Time.deltaTime, Space.World);
        }
        if (transform.parent.position.x>19 && !changingScene)
        {
            FadeManager.Instance.Fade(true, 1, "WinScene");
            changingScene = true;
        }
    }
    public void TurnOff()
    {
        StartCoroutine(FadeOutVan());
    }
    public void MoveRight()
    {
        move = true;
    }
    IEnumerator FadeOutVan()
    {
        ControlJuego.Instancia.DetenerFondo = true;
        for (float t = 0.0f; t < 1.0f; t += Time.deltaTime / time)
        {
            for (int i = 0; i < spriteRenderer.Count; i++)
            {
                Color newColor = new Color(1, 1, 1, Mathf.Lerp(1, 0, t));
                spriteRenderer[i].color = newColor;
            }
         
            yield return null;
        }
        Destroy(ruedas.gameObject);
        Destroy(this.gameObject);
    }
}
