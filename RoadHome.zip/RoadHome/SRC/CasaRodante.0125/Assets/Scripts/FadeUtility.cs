﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class FadeUtility : MonoBehaviour
{
    private void Start()
    {
        FadeIn();
    }
    public void FadeOut()
    {
        StartCoroutine(FadeOutObj());
    }
    public void FadeIn()
    {
        StartCoroutine(FadeInObj());
    }
    IEnumerator FadeOutObj()
    {
        for (float t = 0.0f; t < 1.0f; t += Time.deltaTime / 2)
        {

            Color newColor = new Color(1, 1, 1, Mathf.Lerp(1, 0, t));
            GetComponent<Text>().color = newColor;

            yield return null;
        }
        Color newColor2 = new Color(1, 1, 1, 0);
        GetComponent<Text>().color = newColor2;
    }
    IEnumerator FadeInObj()
    {
        for (float t = 0.0f; t < 1.0f; t += Time.deltaTime / 2)
        {

            Color newColor = new Color(1, 1, 1, Mathf.Lerp(0, 1, t));
            GetComponent<Text>().color = newColor;

            yield return null;
        }
        Color newColor2 = new Color(1, 1, 1, 1);
        GetComponent<Text>().color = newColor2;
    }
}
