﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Generador : MonoBehaviour {

	public TipoArrastable TipoArrastable;
	public Rango RangoGeneracion ;

	// Use this for initialization
	void Start () {
		Inicializar ();
	}
	
	// Update is called once per frame
	void Update () {
		
	}

	public void Inicializar (){
		RangoGeneracion = GetComponentInChildren<Rango> ();
	}

	public void Generar(GameObject Prefabricado, TipoArrastable Tipo, int Valor) {
		//Debug.Log (gameObject.name + ": " + transform.position + " " + ((RangoGeneracion != null)? RangoGeneracion.gameObject.transform.position.ToString() : "nada") );

		Vector3 DeltaPosicion = Vector3.zero;

		if (RangoGeneracion != null) {
			DeltaPosicion = new Vector3(
				Random.Range(0,  RangoGeneracion.transform.position.x - transform.position.x),
				Random.Range(0,  RangoGeneracion.transform.position.y - transform.position.y),
				Random.Range(0,  RangoGeneracion.transform.position.z - transform.position.z)
			);
			//Debug.Log (DeltaPosicion);
		} else
			DeltaPosicion = Vector3.zero;

		GameObject ObjetoGenerado = GameObject.Instantiate (Prefabricado, transform);
		//Debug.Log (ObjetoGenerado.transform.position);

		ObjetoGenerado.transform.Translate( DeltaPosicion );
		//Debug.Log (ObjetoGenerado.transform.position);
		ObjetoGenerado.GetComponent<Arrastrable> ().Inicializar( Tipo,Valor);
		ObjetoGenerado.SetActive (true);

	}
}
