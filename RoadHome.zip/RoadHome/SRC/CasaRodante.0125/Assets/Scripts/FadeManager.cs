﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class FadeManager : MonoBehaviour {
    public static FadeManager Instance;
    public Image fadeImage;
    private bool isInTransition;
    private float transition;
    private bool isShowing;
    private float duration;
    private string sceneName;


    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
        }
        else if (Instance != this)
        {
            Destroy(gameObject);
        }
        
    }
    private void Start()
    {
       // DontDestroyOnLoad(this.gameObject);
    }
    private void Update()
    {
        
        if (!isInTransition)
        {
            return;
        }
        transition += (isShowing) ? Time.deltaTime * (1 / duration) : -Time.deltaTime * (1 / duration);
        fadeImage.color = Color.Lerp(new Color(fadeImage.color.r, fadeImage.color.g, fadeImage.color.b, 0), new Color(fadeImage.color.r, fadeImage.color.g, fadeImage.color.b, 1), transition);
        if (transition>1 || transition<0)
        {
            isInTransition = false;
            if (transition<0)
            {
                fadeImage.enabled = false;
            }
            else
            {
                SceneManager.LoadSceneAsync(sceneName);
            }
            
        }
    }
    public void Fade(bool aShowing,float aDuration,string aScene)
    {
        if (!aShowing && !fadeImage.enabled)
        {
            return;
        }
        sceneName = aScene;
        fadeImage.enabled = true;
        isShowing = aShowing;
        isInTransition = true;
        duration = aDuration;
        transition = (isShowing) ? 0 : 1;

    }
}
