﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DraggableBehaviour : MonoBehaviour {

	public float Velocidad = 5.0f;
    private float frecuencia = 10;
    private float magnitud = 0.7F;
    Arrastrable arrastrable;
    Vector3 jugadorPos;
    Vector3 pos;
    private float sentido;

	void Awake () {
        arrastrable = GetComponent<Arrastrable>();
	}

    private void Start()
    {
        jugadorPos = ControlJuego.Instancia.jugador.transform.position;
        pos = transform.position;
        sentido = transform.position.x - jugadorPos.x > 0 ? -1 : 1;
    }

    // Update is called once per frame
    void Update () {
		if (ControlJuego.Instancia.Corriendo) {
            Vector3 direccionDirigida = (jugadorPos - transform.position).normalized;
            switch (arrastrable.Tipo)
            {
                case TipoArrastable.DIRIGIDOS:
			        transform.Translate (direccionDirigida * Velocidad * Time.deltaTime);
                    break;
                case TipoArrastable.REBOTANTE:
                    magnitud = 2F;
                    frecuencia = 6;
                    Velocidad = 5;
                    pos += direccionDirigida * Time.deltaTime * Velocidad;
                    transform.position = pos + transform.up * Mathf.Abs(Mathf.Sin(Time.time * frecuencia) * magnitud);
                    break;
                case TipoArrastable.OSCILANTES:
                    pos += direccionDirigida * Time.deltaTime * Velocidad;
                    transform.position = pos + transform.up * Mathf.Sin(Time.time * frecuencia) * magnitud;
                    break;
                case TipoArrastable.RECUERDORECTO:
                    transform.Translate(transform.right * sentido * Velocidad * Time.deltaTime);
                    break;
                case TipoArrastable.RECUERDOOSCILANTE:
                    pos += transform.right * sentido * Time.deltaTime * Velocidad;
                    transform.position = pos + transform.up * Mathf.Sin(Time.time * frecuencia) * magnitud;
                    break;
            }
		}
	}
}
