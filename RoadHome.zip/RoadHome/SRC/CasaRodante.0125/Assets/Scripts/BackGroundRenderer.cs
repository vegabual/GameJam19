﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BackGroundRenderer : MonoBehaviour
{
    public float time;
    private List<SpriteRenderer> spriteRenderer = new List<SpriteRenderer>();
    private void Awake()
    {
        foreach (Transform child in transform)
        {
            spriteRenderer.Add(child.GetComponent<SpriteRenderer>());
        }
    }

    public void TurnOn()
    {
        StartCoroutine(FadeInBackground());
    }
    public void TurnOff()
    {
        StartCoroutine(FadeOutBackground());
    }
    IEnumerator FadeOutBackground()
    {
        for (float t = 0.0f; t < 1.0f; t += Time.deltaTime / time)
        {
            for (int i = 0; i < spriteRenderer.Count; i++)
            {
                Color newColor = new Color(1, 1, 1, Mathf.Lerp(1, 0, t));
                spriteRenderer[i].color = newColor;
            }
         
            yield return null;
        }

    }
    IEnumerator FadeInBackground()
    {
        for (float t = 0.0f; t < 1.0f; t += Time.deltaTime / time)
        {
            for (int i = 0; i < spriteRenderer.Count; i++)
            {
                Color newColor = new Color(1, 1, 1, Mathf.Lerp(0, 1, t));
                spriteRenderer[i].color = newColor;
            }

            yield return null;
        }

    }
}
