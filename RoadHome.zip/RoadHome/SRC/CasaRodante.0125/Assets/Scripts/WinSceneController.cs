﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class WinSceneController : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        FadeManager.Instance.Fade(false, 1, "Juego");
    }

   public void Menu()
    {
        FadeManager.Instance.Fade(true, 1, "Menu");
    }
}
