﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Sprites;

public class ScrollBackgrounds : MonoBehaviour
{
    public float speed;
    public float initPosX;
    private SpriteRenderer spriteRenderer;
    private bool runningCorrutine = false;

    void Awake()
    {
        spriteRenderer = GetComponent<SpriteRenderer>();
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        if (!ControlJuego.Instancia.DetenerFondo)
        {
            transform.Translate(new Vector3(-speed, 0, 0) * Time.deltaTime);
            if (transform.position.x < -spriteRenderer.bounds.size.x)
            {
                transform.position = new Vector3((spriteRenderer.bounds.size.x), transform.position.y, transform.position.z);
            }
        }
        else if (!runningCorrutine)
        {
            runningCorrutine = true;
            StartCoroutine(Stop());
        }
    }

    IEnumerator Stop()
    {
        for (float t = 0.0f; t < 1.0f; t += Time.deltaTime / 2.5F)
        {
            if (transform.position.x < -spriteRenderer.bounds.size.x)
            {
                transform.position = new Vector3((spriteRenderer.bounds.size.x), transform.position.y, transform.position.z);
            }
            transform.Translate(Vector3.Lerp(new Vector3(-speed, 0, 0), Vector3.zero, t) * Time.deltaTime);

            yield return null;
        }
        if (ControlJuego.Instancia.RecuerdosCapturados <= 0)
        {
            ControlJuego.Instancia.SaturationOff();
        }
        
    }
}
