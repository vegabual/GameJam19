﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Jugador : MonoBehaviour {
	public ControlJuego Control;
    public List<GameObject> ListaRecuerdos;


	public void OnTriggerEnter2D(Collider2D coll){
		Arrastrable Objetivo = coll.gameObject.GetComponent<Arrastrable> ();
		TratarColision (Objetivo);
     
	}

	void TratarColision(Arrastrable Objetivo){

		if (Objetivo != null) {
            if (Objetivo.Tipo == TipoArrastable.RECUERDORECTO || Objetivo.Tipo == TipoArrastable.RECUERDOOSCILANTE)
				Control.ContarRecuerdo();
			else 
				Control.QuitarRecuerdo (Objetivo.Danio);
			
			GameObject.Destroy (Objetivo.gameObject);
		}

	}

}
