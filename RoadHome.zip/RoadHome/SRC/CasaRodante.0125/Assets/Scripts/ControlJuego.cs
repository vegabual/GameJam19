﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityStandardAssets.ImageEffects;


public class ControlJuego : MonoBehaviour
{

    public static ControlJuego Instancia;
    public Jugador jugador;
    public bool Spawnear = true;
    public bool DetenerFondo = false;

    public bool Corriendo = true;

    public VanFader van;

    public int RecuerdosIniciales = 10;
    public int RecuerdosMaximos = 50;
    public int RecuerdosCapturados = 0;
    private int RecuerdoPrevio = 0;

    public float TiempoGeneracion = 7.0f;
    private float TiempoSiguiente = 0f;
    private float TiempoActual = 0f;
 
    public float ProbabilidadGeneracionRecuerdos = 0f;
    public float ProbabilidadGeneracionEnjambre = 0f;
    public float ProbabilidadGeneracionAve = 0f;
    public float ProbabilidadGeneracionGoma = 0f;
    public float ProbabilidadGeneracionVieja = 0f;
    public float ProbabilidadGeneracionROscilante = 0f;

    public List<GameObject> PreFabs;

    private float AcumuladaRecuerdo { get { return                     ProbabilidadGeneracionRecuerdos; } }
    private float AcumuladaEnjambre { get { return AcumuladaRecuerdo + ProbabilidadGeneracionEnjambre; } }
    private float AcumuladaAve { get { return AcumuladaEnjambre + ProbabilidadGeneracionAve; } }
    private float AcumuladaGoma { get { return AcumuladaAve + ProbabilidadGeneracionGoma; } }
    private float AcumuladaVieja { get { return AcumuladaGoma + ProbabilidadGeneracionVieja; } }
    private float AcumuladaRecuerdoOscilante { get { return AcumuladaVieja + ProbabilidadGeneracionROscilante; } }

    public ControlContador UIContador;
    public List<Generador> GeneradoresRecuerdos;
    public List<Generador> GeneradoresDirigidos;
    public List<Generador> GeneradoresAve;
    public List<Generador> GeneradoresGoma;
    public List<Generador> GeneradoresVieja;

    public GameObject Capturable;
    public ColorCorrectionCurves colorCorrection;

    public List<BackGroundRenderer> backgrounds;
    public GameObject btnRestart;
    float timer = 0;

    private void Awake()
    {
        if (Instancia == null)
        {
            Instancia = this;
        }
        else if (Instancia != this)
        {
            Destroy(this.gameObject);
        }
    }

    // Use this for initialization
    void Start()
    {
        FadeManager.Instance.Fade(false, 1, "Juego");
        RecuerdosCapturados = RecuerdosIniciales;
        RecuerdoPrevio = RecuerdosCapturados;
        ActualizarPonderacion();
    }

    // Update is called once per frame
    void Update()
    {
        if (timer<4)
        {
            timer += Time.deltaTime;
        }
        

        if (Corriendo && Spawnear && timer>=3)
        {

            if (TiempoActual < TiempoSiguiente)
            {
                TiempoActual += Time.deltaTime;
            }
            else
            {
                TiempoActual = 0f;
                TiempoSiguiente = TiempoGeneracion;
                Generar();
            }
            
        }

    }

    public void ContarRecuerdo()
    {
        RecuerdoPrevio = RecuerdosCapturados;
        if (RecuerdosCapturados + 1 > 21)
        {
            RecuerdosCapturados = 21;
        }
        else
        {
            RecuerdosCapturados += 1;
        }
        
        
        UIContador.actualizarNumero(RecuerdosCapturados);
        if (RecuerdosCapturados <= 20 && RecuerdosCapturados > 0)
        {
            jugador.ListaRecuerdos[RecuerdosCapturados - 1].SetActive(!jugador.ListaRecuerdos[RecuerdosCapturados - 1].activeSelf);
            ToggleRecuerdo();
        }
        else
        {
            TerminarJuego();
        }
    }

    public void QuitarRecuerdo(int danio)
    {
        RecuerdoPrevio = RecuerdosCapturados;
        if (RecuerdosCapturados - danio > 0)
        {
            RecuerdosCapturados -= danio;
        }
        else
        {
            RecuerdosCapturados = 0;
        }
        UIContador.actualizarNumero(RecuerdosCapturados);
        if (RecuerdosCapturados < 20 && RecuerdosCapturados > 1)
        {
            jugador.ListaRecuerdos[RecuerdosCapturados].SetActive(!jugador.ListaRecuerdos[RecuerdosCapturados].activeSelf);
            ToggleRecuerdo();
        }

        if (RecuerdosCapturados == 0)
            TerminarJuego();
    }
    private void ToggleRecuerdo()
    {
        ActualizarPonderacion();
        if (RecuerdosCapturados == 10 && RecuerdoPrevio<RecuerdosCapturados)
        {
            backgrounds[0].TurnOff();
         
        }
        else if (RecuerdosCapturados == 9 && RecuerdoPrevio > RecuerdosCapturados)
        {
            backgrounds[0].TurnOn();

        }
        else if (RecuerdosCapturados == 15 && RecuerdoPrevio < RecuerdosCapturados)
        {
            backgrounds[1].TurnOff();
        }
        else if (RecuerdosCapturados == 14 && RecuerdoPrevio > RecuerdosCapturados)
        {
            backgrounds[1].TurnOn();
        }
        else if (RecuerdosCapturados == 17)
        {
            jugador.ListaRecuerdos[20].SetActive(false);
        }
        else if (RecuerdosCapturados == 16)
        {
            jugador.ListaRecuerdos[20].SetActive(true);
        }
    }

    private void ActualizarPonderacion()
    {
        if (RecuerdosCapturados <=5)
        {
            ProbabilidadGeneracionRecuerdos = 0.1f;
            ProbabilidadGeneracionEnjambre = 0.25f;
            ProbabilidadGeneracionAve = 0.25f;
            ProbabilidadGeneracionGoma = 0f;
            ProbabilidadGeneracionVieja = 0f;
            ProbabilidadGeneracionROscilante = 0f;
        }
        else if (RecuerdosCapturados <= 10)
        {
            ProbabilidadGeneracionRecuerdos = 0.05f;
            ProbabilidadGeneracionEnjambre = 0.25f;
            ProbabilidadGeneracionAve = 0.25f;
            ProbabilidadGeneracionGoma = 0f;
            ProbabilidadGeneracionVieja = 0f;
            ProbabilidadGeneracionROscilante = 0.05f;
        }
        else if (RecuerdosCapturados <= 15)
        {
            ProbabilidadGeneracionRecuerdos = 0.04f;
            ProbabilidadGeneracionEnjambre = 0.3f;
            ProbabilidadGeneracionAve = 0.3f;
            ProbabilidadGeneracionGoma = 0f;
            ProbabilidadGeneracionVieja = 0f;
            ProbabilidadGeneracionROscilante = 0.05f;
        }
        else
        {
            ProbabilidadGeneracionRecuerdos = 0.02f;
            ProbabilidadGeneracionEnjambre = 0.25f;
            ProbabilidadGeneracionAve = 0.25f;
            ProbabilidadGeneracionGoma = 0.02f;
            ProbabilidadGeneracionVieja = 0.01f;
            ProbabilidadGeneracionROscilante = 0.05f;
        }
    }
    public void SaturationOff()
    {
        StartCoroutine(ClearSaturation());
    }
    IEnumerator ClearSaturation()
    {
        for (float t = 0.0f; t < 1.0f; t += Time.deltaTime / 1)
        {
            colorCorrection.saturation = Mathf.Lerp(1, 0, t);
           
            yield return null;
        }
        colorCorrection.saturation =0;
        btnRestart.SetActive(true);
    }
    public void Reiniciar()
    {
        FadeManager.Instance.Fade(true, 1, "Juego");
        
    }

    public void TerminarJuego()
    {
        if (RecuerdosCapturados <= 0)
        {
            Debug.Log("PERDISTE :(");
            Spawnear = false;
            van.TurnOff();
            
        }
        else
        {
            Spawnear = false;

            ControlJuego.Instancia.DetenerFondo = true;
            van.MoveRight();
            Debug.Log("PISTEASTE COMO UN CAMPEÓN!!");
        }
    }

    public void Generar()
    {
        float NumeroRandom = Random.Range(0f, AcumuladaRecuerdoOscilante);

        if (NumeroRandom < AcumuladaRecuerdo)
            GenerarRecuerdo();
        else if (NumeroRandom < AcumuladaEnjambre)
            GenerarEnjambre();
        else if (NumeroRandom < AcumuladaAve)
            GenerarAve();
        else if (NumeroRandom < AcumuladaGoma)
            GenerarGoma();
        else if (NumeroRandom < AcumuladaVieja)
            GenerarVieja();
        else if (NumeroRandom < AcumuladaRecuerdoOscilante)
            GenerarRecuerdoOscilante();

    }

    void GenerarRecuerdo()
    {

        if (GeneradoresRecuerdos.Count > 0)
        {
            int NumeroRandom = Random.Range(0, GeneradoresRecuerdos.Count);
            GeneradoresRecuerdos[NumeroRandom].Generar(PreFabs[(int)TipoPreFab.RECUERDO], TipoArrastable.RECUERDORECTO, 1);

        }

    }

    void GenerarRecuerdoOscilante()
    {

        if (GeneradoresRecuerdos.Count > 0)
        {
            int NumeroRandom = Random.Range(0, GeneradoresRecuerdos.Count);
            GeneradoresRecuerdos[NumeroRandom].Generar(PreFabs[(int)TipoPreFab.RECUERDO], TipoArrastable.RECUERDOOSCILANTE, 1);

        }

    }

    void GenerarEnjambre()
    {

        if (GeneradoresDirigidos.Count > 0)
        {
            int NumeroRandom = Random.Range(0, GeneradoresDirigidos.Count);
            if (RecuerdosCapturados <= 15)
            {
                GeneradoresDirigidos[NumeroRandom].Generar(PreFabs[(int)TipoPreFab.ENJAMBRE], TipoArrastable.DIRIGIDOS, 1);
            }
            else
            {
                if (Random.Range(0, 2) == 0)
                {
                    GeneradoresDirigidos[NumeroRandom].Generar(PreFabs[(int)TipoPreFab.ENJAMBRE], TipoArrastable.DIRIGIDOS, 1);
                }
                else
                {
                    GeneradoresDirigidos[NumeroRandom].Generar(PreFabs[(int)TipoPreFab.ENJAMBRE], TipoArrastable.OSCILANTES, 1);
                }
            }
        }

    }

    void GenerarAve()
    {

        if (GeneradoresAve.Count > 0)
        {
            int NumeroRandom = Random.Range(0, GeneradoresAve.Count);
            if (RecuerdosCapturados <= 15)
            {
                GeneradoresAve[NumeroRandom].Generar(PreFabs[(int)TipoPreFab.AVE], TipoArrastable.DIRIGIDOS, 1);
            }
            else
            {
                if (Random.Range(0, 2) == 0)
                {
                    GeneradoresAve[NumeroRandom].Generar(PreFabs[(int)TipoPreFab.AVE], TipoArrastable.DIRIGIDOS, 1);
                }
                else
                {
                    GeneradoresAve[NumeroRandom].Generar(PreFabs[(int)TipoPreFab.AVE], TipoArrastable.OSCILANTES, 1);
                }
            }
           
        }

    }

    void GenerarGoma()
    {
        if (GeneradoresGoma.Count > 0)
        {
            int NumeroRandom = Random.Range(0, GeneradoresGoma.Count);
            GeneradoresGoma[NumeroRandom].Generar(PreFabs[(int)TipoPreFab.GOMA], TipoArrastable.REBOTANTE, 1);
        }
    }

    void GenerarVieja()
    {

        if (GeneradoresVieja.Count > 0)
        {
            int NumeroRandom = Random.Range(0, GeneradoresVieja.Count);
            GeneradoresVieja[NumeroRandom].Generar(PreFabs[(int)TipoPreFab.FITITO], TipoArrastable.DIRIGIDOS, 1);
        }

    }




}

public enum TipoPreFab
{
    RECUERDO,
    ENJAMBRE,
    AVE,
    GOMA,
    FITITO
}
