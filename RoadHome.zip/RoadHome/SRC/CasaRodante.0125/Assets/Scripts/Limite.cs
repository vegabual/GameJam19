﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Limite : MonoBehaviour {

	public ControlJuego Control;

	// Use this for initialization
	void Start () {
	}
	
	// Update is called once per frame
	void Update () {
		
	}

	public void OnTriggerEnter2D(Collider2D Collider) {
		Arrastrable Objetivo = Collider.gameObject.GetComponent<Arrastrable> ();
		TratarColision (Objetivo);

	}

	void TratarColision(Arrastrable Objetivo){
		
		if (Objetivo != null) {
			//Debug.Log (Objetivo.Tipo);
			//if (Objetivo.Tipo == TipoArrastable.RECUERDORECTO)
			//	Control.QuitarRecuerdo ();
			//else if (Objetivo.Tipo == TipoArrastable.DIRIGIDOS && !Objetivo.FueArrastrado)
			//	Control.QuitarRecuerdo ();

			GameObject.Destroy (Objetivo.gameObject);
		}
	
	}
}
