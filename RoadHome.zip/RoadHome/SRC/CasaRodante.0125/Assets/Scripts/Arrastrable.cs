﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Arrastrable : MonoBehaviour {

	public TipoArrastable Tipo = TipoArrastable.DIRIGIDOS;
    public SpawnSite sitio = SpawnSite.ALL;
	public bool FueArrastrado = false;

    public int Danio = 1;

	public Sprite SpriteRecuerdo;
	public List<Sprite> SpriteEnemigos;
    private Vector3 dir;
    private float time = 0.5F;

    DraggableBehaviour moverIzquierda;

    bool dragging = false;
    bool dropped = false;
    
    void Awake () {
        moverIzquierda = GetComponent<DraggableBehaviour>();
	}

    // Update is called once per frame
    private void Update()
    {
        if (!ControlJuego.Instancia.Spawnear)
        {
            StartCoroutine(FadeOutObj());
        }
    }

    void FixedUpdate () {

        if (dragging)
        {
            FollowMouse();
        }
        else if (dropped)
        {
            DropObject();
        }
    }

    public void Dragging()
    {
        dragging = true;
        moverIzquierda.enabled = false;
    }

    public void Drop(Vector3 direction)
    {
        dragging = false;
        dropped = true;
        dir = direction;
    }

	public void Inicializar (TipoArrastable aTipo, int aDanio){
		this.Tipo = aTipo;
		this.Danio = aDanio;
	}


    private void DropObject()
    {
        transform.Translate(dir * Time.deltaTime, Space.World);
    }

    private void FollowMouse()
    {
        transform.position = new Vector3(Camera.main.ScreenToWorldPoint(Input.mousePosition).x, Camera.main.ScreenToWorldPoint(Input.mousePosition).y, 0);
    }
    
    IEnumerator FadeOutObj()
    {
        for (float t = 0.0f; t < 1.0f; t += Time.deltaTime / time)
        {
            
            Color newColor = new Color(1, 1, 1, Mathf.Lerp(1, 0, t));
            GetComponent<SpriteRenderer>().color = newColor;

            yield return null;
        }
        Destroy(this.gameObject);
    }
}

public enum TipoArrastable {
	RECUERDORECTO,
    RECUERDOOSCILANTE,
	DIRIGIDOS,
    OSCILANTES,
    REBOTANTE
}

public enum SpawnSite
{
    STREETL,
    STREETR,
    ALL,
    SIDES
}
