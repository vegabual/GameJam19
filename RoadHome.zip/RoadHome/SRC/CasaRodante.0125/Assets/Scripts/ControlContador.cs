﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;

public class ControlContador : MonoBehaviour {
	private Text Texto = null;

	// Use this for initialization
	void Start () {
		ObtenerTexto ();
	}
	
	
	void ObtenerTexto(){
		Texto = gameObject.GetComponent<Text> ();

	}

	public void actualizarNumero(int Numero){
		if (Texto != null)
			Texto.text = Numero.ToString() + "/21";
	}
}
